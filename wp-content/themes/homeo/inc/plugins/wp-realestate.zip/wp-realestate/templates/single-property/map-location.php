<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
global $post;

?>
<div class="property-detail-map-location">
    <div id="properties-google-maps" class="single-property-map"></div>
</div>